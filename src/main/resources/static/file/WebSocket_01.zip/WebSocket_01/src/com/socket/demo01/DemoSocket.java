package com.socket.demo01;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.chat.user.UserCenter;
import com.data.Message;
import com.data.Result;

@ServerEndpoint("/echo")
public class DemoSocket {
	
	private static CopyOnWriteArraySet<DemoSocket> webSocketSet = new CopyOnWriteArraySet<DemoSocket>();
	
	private static Map<String,Session> socket=new HashMap<String,Session>();
	
	private  static final AtomicInteger onlineCount = new AtomicInteger(0);
	
	private static List<String> names=new ArrayList<String>();
	// ��ĳ���ͻ��˵����ӻỰ����Ҫͨ���������ͻ��˷�������
    private Session session;
    
    private String name;
	
    public DemoSocket(){
    	name="�ÿ�:"+onlineCount.getAndIncrement();
    }
	
	@OnOpen
	public void open(Session session) throws UnsupportedEncodingException{
		this.session=session;
		webSocketSet.add(this);
		String queryStr=session.getQueryString();//��ȡ�ʺź���Ĳ���
		this.name=URLDecoder.decode(queryStr.substring(queryStr.indexOf("=")+1), "utf-8");
		socket.put(this.name,session);
		names.add(name);
		//�����û����� 2016-08-04 15:16
		UserCenter.userCenter.addSession(this.name, session);
		//-------------------------
		Message msg=new Message();
		msg.setContent(this.name);
		msg.setName(this.name);
		msg.setNames(names);
		msg.setDbType(2);
		JSONArray json=JSONArray.fromObject(msg);
		broadcast(json.toString());
	}
	
	@OnClose
	public void close(){
		webSocketSet.remove(this);
		Set<String>kset=socket.keySet();
		for (String string : kset) {
			if(session.getId().equals(socket.get(string).getId())){
				Message m=new Message();
				names.remove(string);
				m.setDbType(3);
				m.setContent(string);
				m.setNames(names);
				JSONArray json=JSONArray.fromObject(m);
				broadcast(json.toString());
			}
		}
		
		
		
	}
	
	@OnMessage
	public void onmessage(Session session,String msg,boolean last){
		Result result=Result.result;
		result.setMsg(msg);
		try {
			//session.getBasicRemote().sendText("me");
			Message m=new Message();
			m.setDbType(1);
			m.setContent(msg);
			m.setName(this.name);
			m.setPublisher(this.name);
			m.setDate(new Date().toLocaleString());
			JSONArray json=JSONArray.fromObject(m);
			this.broadcast(json.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	//Ⱥ��
	private void broadcast(String info){
		
		for (DemoSocket w : webSocketSet) {
			try {
					synchronized (DemoSocket.class){
						
					w.session.getBasicRemote().sendText(info);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	 }
}
