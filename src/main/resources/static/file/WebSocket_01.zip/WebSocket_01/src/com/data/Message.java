package com.data;

import java.util.Date;
import java.util.List;

public class Message {
	private String name;
	private List<String> names;
	
	private String content;
	
	private String date;
	
	private String publisher;
	
	private int  dbType;//1:����;2:����֪ͨ;3:����֪ͨ;
	
	

	public int getDbType() {
		return dbType;
	}

	public void setDbType(int dbType) {
		this.dbType = dbType;
	}

	

	@Override
	public String toString() {
		return "Message [name=" + name + ", names=" + names + ", content="
				+ content + ", date=" + date + ", publisher=" + publisher
				+ ", dbType=" + dbType + ", getDbType()=" + getDbType()
				+ ", getName()=" + getName() + ", getNames()=" + getNames()
				+ ", getContent()=" + getContent() + ", getDate()=" + getDate()
				+ ", getPublisher()=" + getPublisher() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	
	
	
	
}
